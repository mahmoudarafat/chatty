<?php

return [
    'add_intro'            => 'إضافة مقدمة',
    'edit_intro'            => 'تعديل مقدمة',
    'intro_added'          => 'تم إضافة المقدمة بنجاح',
    'intro_image'          => 'صورة المقدمة',
    'no_data_found'        => 'لا توجد بيانات',
    'intro_title_ar'       => 'عنوان المقدمة بالعربية',
    'intro_title_en'       => 'عنوان المقدمة بالإنجليزية',
    'intro_description_ar' => 'وصف المقدمة بالعربية',
    'intro_description_en' => 'وصف المقدمة بالإنجليزية',
    'somthing_error'       => 'حدث خطأ ما',
    'intro_edited'         => 'تم تعديل المقدمة بنجاح',
    'intro_deleted'        => 'تم حذف المقدمة بنجاح',
];
